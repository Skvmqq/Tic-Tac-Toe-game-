#include <iostream>

#include "Gameloop.h"

int main() {
    Gameloop gl;
    return 0;
}
