#include "Gameloop.h"

using namespace std;

void Gameloop::print_menu()
{
    cout << "***************************************************************  TIC TAC TOE TOE GAME      ***************************************************************" << endl;
    cout << "*******************************************************************       MENU          *******************************************************************" << endl;
    cout << "*****************************************************************   1- Enter 1 to play game   *****************************************************************" << endl;
    cout << "****************************************************************   2- Enter 2 to check total history ****************************************************************" << endl;
    cout << "****************************************************************   3- Enter 3 to check history of the current session ****************************************************************" << endl;
    cout << "4 -Enter 3 to exit" << endl;
    return;
}


Gameloop::Gameloop()
{
    try
    {
        history_file.open("History.txt", fstream::in | fstream::app);

        if (!history_file.is_open())
        {
            //File does not exist
            history_file.open("history.txt", fstream::out);
            if (!history_file)
            {
                throw runtime_error("Cannot create history.txt.");
            }
            history_file.close();
            history_file.open("History.txt", fstream::in | fstream::app);
        }
    }
    catch (exception ex)
    {
        cerr << "Exception occurred: " << ex.what() << endl;
    }

    print_logo();
    print_menu();
    while (choice != 4)
    {
        try
        {
            cin >> choice;
            if (cin.fail())
            {
                throw runtime_error("Invalid input.");
            }
        }
        catch (runtime_error& ex)
        {
            system("cls");
            cin.clear();
            cin.ignore();
            print_logo();
            print_menu();
            cerr << ex.what() << endl;
            continue;
        }
        switch (choice)
        {
            case 1:
                enter_names();
                game.startGame(player_1, player_2);
                winner = game.getWinner();
                temp = result_string();
                cout << temp << endl;
                history_file << temp << endl;
                games_played++;
                temp_arr = new string[games_played];
                for (int i = 0; i < games_played - 1; i++)
                {
                    temp_arr[i] = history[i];
                }
                temp_arr[games_played - 1] = temp;
                delete[] history;
                history = temp_arr;
                print_menu();
                break;
            case 2:
                history_file.seekg(0, std::ios::beg);
                while (std::getline(history_file, temp2))
                {
                    std::cout << temp2 << std::endl;
                }
                history_file.clear();
                print_menu();
                break;
            case 3:

                if (history != NULL)
                    for (int i = 0; i < games_played; i++)
                    {
                        cout << history[i] << endl;
                    }
                print_menu();
                break;
            case 4:
                delete[] history;
                delete[] temp_arr;
                history_file.close();
                break;
            default:
                system("cls");
                cin.clear();
                cin.ignore();
                print_logo();
                print_menu();
                cout << "Enter a valid value." << endl;
                ;
        }
    }
}

string Gameloop::result_string()
{
    string temp_string;
    switch (winner)
    {
        case 1:
            temp_string = "Winner: Player 1: " + player_1 + '\t' + "Symbol: x " + '\t' + "Moves: " + to_string(game.getMoves());
            break;
        case 2:
            temp_string = "Winner: Player 2: " + player_1 + '\t' + "Symbol: o " + '\t' + "Moves: " + to_string(game.getMoves());
            break;
        case 3:
            temp_string = "Draw!";
            break;
    }

    return temp_string;
}

string Gameloop::input_name()
{
    string name;
    bool check = false;
    while (check != true)
    {
        try
        {
            cin >> name;
            if (cin.fail())
            {
                throw runtime_error("Invalid input.");
            }
            check = true;
        }
        catch (runtime_error& ex)
        {
            cin.clear();
            cin.ignore();
            cerr << ex.what() << endl;
            continue;
        }
    }
    return name;
}

void Gameloop::enter_names()
{
    cout << "Enter player 1 name: ";
    player_1 = input_name();
    cout << "Enter player 2 name: ";
    player_2 = input_name();
}

void Gameloop::print_logo()
{
    cout <<
         " _______ _______ _______ _______ _______ _______ _______ _______ _______ _______ _______\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|   T   |   I   |   C   |       |   T   |   A   |   C   |       |   T   |   O   |   E   |\n"
         "|_______|_______|_______|_______|_______|_______|_______|_______|_______|_______|_______|\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|   T   |   A   |   C   |       |   T   |   A   |   C   |       |   T   |   O   |   E   |\n"
         "|_______|_______|_______|_______|_______|_______|_______|_______|_______|_______|_______|\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|       |       |       |       |       |       |       |       |       |       |       |\n"
         "|   T   |   O   |   E   |       |   T   |   A   |   C   |       |   T   |   O   |   E   |\n"
         "|_______|_______|_______|_______|_______|_______|_______|_______|_______|_______|_______|\n"
         << endl;
}

