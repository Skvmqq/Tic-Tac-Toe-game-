#pragma once

#include <iostream>
#include <string>

#include <fstream>
#include <cstdlib>
#include "Gamelogic.h"

class Gameloop
{
private:
    int choice;
    int games_played;
    std::fstream history_file;
    std::string* history = NULL;
    std::string* temp_arr = NULL;
    //std::vector<std::string> history;
    void print_menu();
    void print_logo();
    std::string input_name();
    void enter_names();
    std::string result_string();
    Gamelogic game;
    std::string temp;
    std::string temp2;

    std::string player_1, player_2;
    int winner;

public:
    Gameloop();
};


