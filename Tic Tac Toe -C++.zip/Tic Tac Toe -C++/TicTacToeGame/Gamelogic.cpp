#include "Gamelogic.h"
#include <iostream>
using namespace std;

void Gamelogic::startGame(string player_1, string player_2)
{
    this->player_1 = player_1;
    this->player_2 = player_2;

    for (int i = 0; i < 3; i++)
    {
        board[i] = "    ";
    }
    symbol_1 = 'x';
    symbol_2 = 'o';
    run_game();
}

string Gamelogic::getPlayer1() const
{
    return player_1;
}

string Gamelogic::getPlayer2() const
{
    return player_2;
}

int Gamelogic::getMoves()
{
    return moves_count;
}

void Gamelogic::print_board()
{
    cout << ' ' << board[0][0] << " | " << board[0][1] << " | " << board[0][2] << endl;
    cout << "___________" << endl;
    cout << ' ' << board[1][0] << " | " << board[1][1] << " | " << board[1][2] << endl;
    cout << "___________" << endl;
    cout << ' ' << board[2][0] << " | " << board[2][1] << " | " << board[2][2] << endl;
}

void Gamelogic::update(char symbol)
{
    int x, y;
    bool check = false;

    if (symbol == 'x')
        cout << "Player 1: ";
    else
        cout << "Player 2: ";
    cout << "Enter the row and column number  between 0-2 (2 numbers) where you wish to  place your " << symbol << endl;


    while (check != true)
    {
        try
        {
            cin >> x >> y;
            if (cin.fail())
            {
                throw runtime_error("Invalid input.");
            }

            if (!((x >= 0 && x < 3) && (y >= 0 && y < 3)))
            {
                throw runtime_error("Coordinates out of bounds.");
            }

            if (this->board[x][y] != ' ')
            {
                throw runtime_error("Coordinates already occupied.");
            }
            check = true;
        }
        catch (runtime_error& ex)
        {
            cin.clear();
            cin.ignore();
            cerr << ex.what() << endl;
            continue;
        }
    }

    this->board[x][y] = symbol;
}


bool Gamelogic::checkWin()
{
    for (int i = 0; i < 3; i++)
    {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ')
        {
            winner = (board[i][0] == 'x') ? 1 : 2;
            return true;
        }
    }

    for (int j = 0; j < 3; j++)
    {
        if (board[0][j] == board[1][j] && board[1][j] == board[2][j] && board[0][j] != ' ')
        {
            winner = (board[0][j] == 'x') ? 1 : 2;
            return true;
        }
    }

    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ')
    {
        winner = (board[0][0] == 'x') ? 1 : 2;
        return true;
    }

    if (board[2][0] == board[1][1] && board[1][1] == board[0][2] && board[2][0] != ' ')
    {
        winner = (board[2][0] == 'x') ? 1 : 2;
        return true;
    }

    return false;
}

int Gamelogic::getWinner()
{
    return winner;
}


void Gamelogic::run_game()
{
    while (checkWin() != true)
    {
        update('x');
        print_board();
        moves_count++;
        if (checkWin())
        {
            break;
        }
        if (moves_count == 9)
        {
            winner = 3;
            break;
        }
        update('o');
        print_board();
        moves_count++;
        if (checkWin())
        {
            break;
        }
    }
}