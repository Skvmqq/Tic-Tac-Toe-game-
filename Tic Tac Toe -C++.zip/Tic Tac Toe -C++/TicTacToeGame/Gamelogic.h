
#pragma once

#include <string>
class tic;

class Gamelogic
{
private:
    std::string board[3];
    std::string player_1;
    std::string player_2;
    char symbol_1, symbol_2;
    int moves_count = 0;
    int winner = -1;

public:
    void startGame(std::string player_1, std::string player_2);
    std::string getPlayer1() const;
    std::string getPlayer2() const;
    int getMoves();
    void print_board();
    void update(char symbol);
    bool checkWin();
    int getWinner();
    void run_game();
};